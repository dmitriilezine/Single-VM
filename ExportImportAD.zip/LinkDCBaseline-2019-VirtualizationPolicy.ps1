﻿<#
    .NOTES
        Copyright (c) Microsoft Corporation.  All rights reserved.

        Use of this sample source code is subject to the terms of the Microsoft
        license agreement under which you licensed this sample source code. If
        you did not accept the terms of the license agreement, you are not
        authorized to use this sample source code. For the terms of the license,
        please see the license agreement between you and Microsoft or, if applicable,
        see the LICENSE.RTF on your install media or the root of your tools installation.
        THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES.
       
    .DESCRIPTION
        V1.0 1 April 2019 (not an April Fool) - Initial Version
        V1.1 25 May 2019 updated linking system guard
#>

$DomainDN = get-ADDomain |select -ExpandProperty DistinguishedName

Set-GPLink -Name "*- Tier 0 DCs Windows Server 2019 Disable System Guard Secure Launch" -Target "ou=Domain Controllers,$DomainDN" -LinkEnabled Yes
Set-GPLink -Name "*- Tier 0 DCs MSFT Windows Server 2019 - Domain Controller Virtualization Based Security" -Target "ou=Domain Controllers,$DomainDN" -LinkEnabled Yes
