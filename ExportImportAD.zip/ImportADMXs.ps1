﻿<#
    .NOTES
        Copyright (c) Microsoft Corporation.  All rights reserved.

        Use of this sample source code is subject to the terms of the Microsoft
        license agreement under which you licensed this sample source code. If
        you did not accept the terms of the license agreement, you are not
        authorized to use this sample source code. For the terms of the license,
        please see the license agreement between you and Microsoft or, if applicable,
        see the LICENSE.RTF on your install media or the root of your tools installation.
        THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES.
       
    .DESCRIPTION
        v1.3 22 March 2020 - Reworked
        v1.2 25 May 2019   - Removed EMET 5.5
        v1.1 27 April 2018 - Added UserProxySettings ADMX
        V1.0 29 July 2016  - Script creation
#>

param (
    [Parameter(Mandatory=$true)]
    [String]$BackupFolder = $null
)

# Copy ADMX and ADML to DC policy storage
if (![String]::IsNullOrEmpty($BackupFolder) -and (Test-Path -Path "$BackupFolder\ADMXs")) {
    $files = Get-ChildItem -Path "$BackupFolder\ADMXs" -File -ErrorAction SilentlyContinue
    foreach ($file in $files) {
        if (!$file) {
            continue
        }
        if (($file.Extension -ieq '.admx') -or ($file.Extension -ieq '.adm')) {
            Copy-Item -Path $file.FullName -Destination 'C:\Windows\PolicyDefinitions' -Force
        } elseif ($file.Extension -ieq '.adml') {
            Copy-Item -Path $file.FullName -Destination 'C:\Windows\PolicyDefinitions\en-us' -Force
        }
    }
} else {
    Write-Host "Path '$BackupFolder\ADMXs' not found" -ForegroundColor Red
}
