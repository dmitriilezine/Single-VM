﻿<#
    .NOTES
        Copyright (c) Microsoft Corporation.  All rights reserved.

        Use of this sample source code is subject to the terms of the Microsoft
        license agreement under which you licensed this sample source code. If
        you did not accept the terms of the license agreement, you are not
        authorized to use this sample source code. For the terms of the license,
        please see the license agreement between you and Microsoft or, if applicable,
        see the LICENSE.RTF on your install media or the root of your tools installation.
        THE SAMPLE SOURCE CODE IS PROVIDED "AS IS", WITH NO WARRANTIES.
       
    .DESCRIPTION
        V1.5 21 March 2020 - Handled errors, removed 2016 - Domain Security GPO
        V1.4 1 April 2019 (not an April Fool) - Commented out 2019 DC Virtualization Policy
        V1.6 29 March 2019 - Updated for Windows Server 2019
        v1.5 1 July 2018 - Updated for removing EMET.
        v1.4 28 June 2018 - Updated for a Typo in DCs Defender policy.
        v1.3 28 April 2018 - Updated for GPO Rename 
        V1.2 12 September 2017 - Updated for 1703 Baselines
        V1.1 02 February 2017 - #'d out Cred Guard policy and renamed policies
        V1.0 16 August 2016
        

#>

$parameters = @{
    'ErrorAction' = 'SilentlyContinue'
}

$DomainDN = Get-ADDomain @parameters | Select-Object -ExpandProperty DistinguishedName

Set-GPLink -Name "*- Tier 0 DCs MSFT Windows Server 2019 - Domain Controller" -Target "ou=Domain Controllers,$DomainDN" -LinkEnabled Yes @parameters
#Set-GPLink -Name "*- Tier 0 DCs MSFT Windows Server 2019 - Domain Controller Virtualization Based Security" -Target "ou=Domain Controllers,$DomainDN" -LinkEnabled Yes @parameters
Set-GPLink -Name "*- Tier 0 DCs MSFT Windows 10 1809 and Server 2019 - Defender Antivirus" -Target "ou=Domain Controllers,$DomainDN" -LinkEnabled Yes @parameters
Set-GPLink -Name "*- Tier 0 DCs MSFT Internet Explorer 11 - Computer" -Target "ou=Domain Controllers,$DomainDN" -LinkEnabled Yes @parameters

Remove-GPO -Name "*- Tier 0 DCs MSFT Windows Server 2012 R2 Domain Controller Baseline" @parameters
Remove-GPO -Name "*- WMI Filter Placeholder GPO - Not in Use" @parameters
Remove-GPO -Name "*- Tier 0 DCs SCM Windows Server 2016 - Domain Controller Baseline" @parameters
Remove-GPO -Name "*- Tier 0 DCs MSFT Windows 10 and Server 2016 Defender" @parameters
Remove-GPO -Name "*- MSFT Windows 10 and Server 2016 - Domain Security" @parameters
