﻿<#
.SYNOPSIS
    This file is part of Security Modernization Suite.

    Adds a deny for the group 'Tier 0 Build Domain Controller using MDT' on DC
    security baselines.

.DESCRIPTION
    Adds a deny for the group 'Tier 0 Build Domain Controller using MDT' on DC
    security baselines.

.EXAMPLE
    Adds a deny for the group 'Tier 0 Build Domain Controller using MDT' on DC
    security baselines:
    PS> .\SetDenyonDCGPOs.ps1

.OUTPUTS
    True on success, false otherwise.

.NOTES
    Authors
        [JS] Jon Sabberton <Jon.Sabberton@microsoft.com>
        [GS] Gregory Schiro <Gregory.Schiro@microsoft.com>

    2020-03-21, version 2.0
        [GS] Full rework of the script. Main changes described below:
             - Deny permissions are now applied,
             - Check if the GPOs exist,
             - Target the PDC,
             - Added flexibility and error handling.

    2019-03-29, version 1.2
        [JS] Updated for Windows Server 2019 Implementation.

    2018-04-28, version 1.1
        [JS] Updated for GPO Rename.

    2017-02-02, version 1.0
        [JS] Script creation.

    The sample scripts provided here are not supported under any Microsoft
    standard support program or service. All scripts are provided AS IS without
    warranty of any kind. Microsoft further disclaims all implied warranties
    including, without limitation, any implied warranties of merchantability or
    of fitness for a particular purpose. The entire risk arising out of the use
    or performance of the sample scripts and documentation remains with you. In
    no event shall Microsoft, its authors, or anyone else involved in the
    creation, production, or delivery of the scripts be liable for any damages
    whatsoever (including, without limitation, damages for loss of business
    profits, business interruption, loss of business information, or other
    pecuniary loss) arising out of the use of or inability to use the sample
    scripts or documentation, even if Microsoft has been advised of the
    possibility of such damages.
#>

#Requires -Version 3.0

# GPOs to update.
$gpoNames = @(
    '*- Tier 0 DCs SCM Windows Server 2016 - Domain Controller Baseline'
    '*- Tier 0 DCs MSFT Windows Server 2012 R2 Domain Controller Baseline'
    '*- Tier 0 DCs MSFT Windows Server 2019 - Domain Controller'
)

function Apply-GpoPermissions($Gpo, $Domain) {
    try {
        $adgpo = [ADSI]"LDAP://CN=`{$($Gpo.Id)`},CN=Policies,CN=System,$($Domain.DistinguishedName)"
        $rule = New-Object System.DirectoryServices.ActiveDirectoryAccessRule(
                [System.Security.Principal.NTAccount]"$($Domain.NetBIOSName)\Tier 0 Build Domain Controller using MDT",
		        "ExtendedRight",
		        "Deny",
		        [Guid]"edacfd8f-ffb3-11d1-b41d-00a0c968f939"
	    )
        $acl = $adgpo.ObjectSecurity
        $acl.AddAccessRule($rule)
        $adgpo.CommitChanges()
    } catch {
        Add-Log -Log "Error while setting permission in GPO '$($Gpo.DisplayName)'. $_" -Type Error
        return $false
    }
    return $true
}

$domain = $null
try {
    $domain = Get-ADDomain -ErrorAction Stop
} catch {
    Add-Log -Log "Error while getting AD domain. $_" -Type Error
    return $false
}
$parameters = @{
    'ErrorAction' = 'SilentlyContinue'
    'Server' = $domain.PDCEmulator
}
$success = $true
foreach ($gpoName in $gpoNames) {
    $g = Get-GPO -Name $gpoName @parameters
    if (!$g) {
        continue
    }
    if (!(Apply-GpoPermissions -Gpo $g -Domain $domain)) {
        $success = $false
    }
}

return $success
