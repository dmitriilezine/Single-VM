Basic Usage for Tier Model Deployment

To deploy the Tier Model with all Windows 10 versions linked use the following command

.\ExportImport-AD -restoreall -backupfolder <BackupFolder> -settingsfile .\settings.xml -linkGPOs


To deploy the Tier Model with the latest Windows 10 and Windows Server 2019 policies only

.\ExportImport-AD -restoreall -backupfolder <BackupFolder> -settingsfile .\settingslatest.xml -linkGPOs

Custom Usage

To deploy custom ExportImport versions with the restoreall switch also consider using the -SkipADMXs or -SkipRoleDefinitions switch as well.

